# Smart Calorie Tracker – Standalone Android App (PWA)

This is a complete **Progressive Web App (PWA)** of the Smart Calorie Tracker.  
On Android it installs and runs as a **standalone app** (no browser UI, home screen icon, offline).

## How to make it live (GitHub Pages)

1. Open your repo: https://github.com/shamvignesh97/Newer-
2. Click **Add file** → **Upload files**
3. Upload these 4 files from the zip:
   - `index.html`
   - `manifest.json`
   - `sw.js`
   - `README.md`
4. Commit the changes.
5. Go to **Settings** → **Pages**
6. Under **Source**, choose **Deploy from a branch**
7. Branch: `main` , folder: `/ (root)` → **Save**
8. Wait 1–2 minutes.

Your live app will be at:

**https://shamvignesh97.github.io/Newer-/**

## Install on Android
1. Open the live link above in **Chrome**.
2. Menu (⋮) → **Install app** / **Add to Home screen**.
3. Done. It now opens like a native app.

## Features
- Dark / Light theme toggle
- Full localStorage memory
- Today / Weekly / Monthly / Agents views
- 90+ South Indian foods + drinks + junk
- Offline after first visit

All data stays only on your phone.
